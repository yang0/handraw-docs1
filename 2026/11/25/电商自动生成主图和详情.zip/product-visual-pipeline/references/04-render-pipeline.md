# 渲染流水线

## 为什么不用图像模型直接生成文字

中文笔画在生成模型里必然糊化、缺笔、错字。所以文字必须由浏览器渲染——矢量、清晰、可精确控制位置。改文案、改价格、换配色都只改 CSS，不用重出底图。

## 整体结构

```
底图（无文字） + HTML 版式（文字层） → 浏览器渲染 → PNG
```

三份东西分离：

| 文件 | 作用 | 谁改 |
|---|---|---|
| `img/*.png` | 底图，只管画面 | 换图时替换 |
| `build.py` | 版式与文案定义 | 改文案、改位置 |
| `render.py` | 批量渲染 | 基本不动 |

## HTML 结构（固定骨架）

```html
<div class="stage" style="height:820px">
  <img src="inner.png" style="height:820px;object-position:50% 50%">
  <!-- 渐变蒙版 -->
  <div class="ov" style="left:0;right:0;bottom:0;height:300px;
       background:linear-gradient(0deg,rgba(255,255,255,0.96) 0%,
       rgba(255,255,255,0.7) 50%,rgba(255,255,255,0) 100%)"></div>
  <!-- 文字层 -->
  <div class="ov" style="left:46px;bottom:46px;width:520px">
    <div class="num">07 — 内壁</div>
    <div class="h" style="font-size:44px">316 不锈钢<em>内胆</em></div>
    <div class="sub">一体拉伸成型，无涂层不脱落。</div>
  </div>
  <div class="pg" style="right:40px;top:48px">07 / 15</div>
</div>
```

## CSS 要点

```css
*{margin:0;padding:0;box-sizing:border-box}
html,body{width:750px;overflow:hidden}
body{
  font-family:"Microsoft YaHei","PingFang SC","Noto Sans CJK SC",sans-serif;
  color:#10281C;background:#fff;
  -webkit-font-smoothing:antialiased;
}
.stage{position:relative;width:750px;overflow:hidden;background:#F4F2ED}
.stage>img{width:100%;display:block;object-fit:cover}

/* 文字层通用 */
.ov{position:absolute}

/* 标题：大字 + 白晕，保证压图可读 */
.h{
  font-weight:800;letter-spacing:-1.5px;line-height:1.16;
  text-shadow:0 2px 34px rgba(255,255,255,0.96),
              0 0 12px rgba(255,255,255,0.8);
}
.h em{font-style:normal;color:#E4500A}   /* 只强调一个关键词 */

/* 序号角标 */
.num{font-size:12px;font-weight:700;letter-spacing:3px;color:#E4500A;
     text-shadow:0 1px 14px rgba(255,255,255,0.95)}

/* 正文 */
.sub{font-size:14.5px;color:#3A4A3E;line-height:1.7;font-weight:500;
     text-shadow:0 1px 18px rgba(255,255,255,0.98)}

/* 页码 */
.pg{position:absolute;font-size:11px;letter-spacing:2px;
    color:rgba(16,40,28,0.36);font-weight:600}
```

**关键**：`.stage` 必须有固定高度，且等于截图的窗口高度。这样内容不会溢出，也不需要事后裁剪。

## 渲染命令

```bash
chrome --headless=new \
  --disable-gpu --no-sandbox --hide-scrollbars \
  --force-device-scale-factor=2 \
  --virtual-time-budget=6000 \
  --window-size=750,820 \
  --screenshot="out.png" \
  "file:///C:/path/to/page.html"
```

| 参数 | 作用 | 不加会怎样 |
|---|---|---|
| `--headless=new` | 无头模式 | — |
| `--force-device-scale-factor=2` | 2 倍分辨率 | 文字发虚，成图宽度只有 750 |
| `--virtual-time-budget=6000` | 等图片加载完再截 | 截到空白或半加载 |
| `--window-size=W,H` | 视口尺寸，H 必须等于 `.stage` 高度 | 内容被裁或底部大片空白 |
| `--hide-scrollbars` | 隐藏滚动条 | 右侧多出 15px 白边 |

## 中文路径处理（必做）

浏览器不接受裸中文路径，必须转 URL 编码：

```python
import urllib.parse
url = "file:///" + urllib.parse.quote(path.replace("\\", "/"))
```

不转的话，截图会静默失败或输出空白页。

## 批量渲染脚本

见 `scripts/render.py`。核心逻辑：

```python
JOBS = [
    ("w02.html", "02-全景.png", 980),
    ("w03.html", "03-多色.png", 640),
    # (html, 输出名, stage 高度)
]

for html, out, h in JOBS:
    url = "file:///" + urllib.parse.quote(...)
    subprocess.run([CHROME, "--headless=new", "--disable-gpu", "--no-sandbox",
                    "--hide-scrollbars", "--force-device-scale-factor=2",
                    "--virtual-time-budget=6000",
                    "--window-size=750,%d" % h,
                    "--screenshot=" + dst, url], timeout=180)
```

## 需要裁剪的情况

只有当页面高度是**自适应**（不是固定 stage 高度）时才需要裁。此时用 numpy 找出内容最后一行：

```python
import numpy as np
from PIL import Image

def trim(path, bg, keep=80):
    img = Image.open(path).convert("RGB")
    arr = np.array(img)
    diff = np.abs(arr.astype(int) - np.array(bg)).max(axis=2)
    rows = np.where((diff > 12).any(axis=1))[0]
    if len(rows) == 0:
        return
    h = min(arr.shape[0], rows[-1] + 1 + keep)
    img.crop((0, 0, arr.shape[1], h)).save(path, optimize=True)
```

**踩坑**：`bg` 参数必须传这一页的真实背景色。

- 浅色页 → `(255,255,255)`
- 深色页 → 该深色的 RGB，例如 `(16,40,28)`

原因：CSS 规范里 `body` 的背景色会传播到画布，深色页整屏都是深色，若仍按白色判断，会找不到内容边界，裁剪直接失效（输出保持整个窗口高度）。

**现成实现**：`scripts/render.py` 已经内置这一步。在 `jobs.json` 里给每一页写 `"bg": [r,g,b]` 即可，浅色页省略（默认白），不想裁的页写 `"bg": "none"`。不要另外再写一份裁剪脚本。

## 迭代流程

```
改 build.py 里的文案  →  跑 build.py 生成 HTML  →  跑 render.py 出图  →  拼图自检
```

单屏改文案不超过一分钟。不要为了改一句话去重新生成底图。

## 成图规格

| 项 | 值 |
|---|---|
| 详情页宽度 | 1500px（750 CSS × 2） |
| 单屏高度 | 1280–2000px（随 stage 高度） |
| 主图 | 1600×1600 |
| 格式 | PNG，`optimize=True` |

拼接上传时按序号顺序纵向拼即可。
