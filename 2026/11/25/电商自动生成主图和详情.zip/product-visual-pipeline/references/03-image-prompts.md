# 生图 Prompt 模板

## 通用结构

一条可用的商品图 prompt 必须包含六段，缺一段就会出问题：

```
1. 画幅与用途      square 1:1 e-commerce product photo / vertical 2:3 detail page image
2. 主体描述        产品类型 + 材质 + 颜色 + 关键配件 + 视角
3. 构图与占比      占画面多少、位置在哪、与什么同框
4. 光影            方向、软硬、要勾出什么质感
5. 背景            色调、虚化程度、是否暗示场景
6. 留白与否定      empty space for text overlay + 全部禁止项
```

## 否定词清单（每条 prompt 都要带）

```
No text, no letters, no labels, no logo, no watermark, no people, no hands.
```

按需追加的否定项——这些是实测最容易出错的：

| 出错表现 | 追加的否定词 |
|---|---|
| 底座多出喇叭形/托盘 | `no pedestal, no foot ring, no flared foot, flat flush base sitting directly on the surface` |
| 把手丢了、变成提环 | `PROMINENT SIDE HANDLE protruding horizontally from the body, like a mug handle, ABSOLUTELY NO top loop handle, no carry ring` |
| 要杯底画成杯盖 | `the cup is turned fully upside down so its flat circular base faces the camera` |
| 多手/多部件 | `exactly one product, no duplicates, no extra parts` |

## 八类场景模板

### 1. 整机全景（白底）

```
Clean e-commerce product photograph on a pure white seamless background:
[产品描述], standing upright in three-quarter view, [把手/配件明确描述].
Full product visible from base to top with even margin all around.
Soft even studio lighting, subtle contact shadow beneath, no color cast.
Extremely sharp, photorealistic, catalogue style.
No text, no letters, no logo, no watermark, no people, no hands.
```

### 2. 多色/多规格合影

```
E-commerce colour option lineup photograph: five identical [产品]
standing in a neat row on a pure white seamless background, evenly spaced
at the same distance, each a different colour from left to right: [颜色列表].
All same height and model, [材质描述], soft even studio lighting,
subtle individual contact shadows, symmetrical catalogue composition.
No text, no letters, no logo, no watermark, no people, no hands.
```

### 3. 尺寸/容量对比

```
Three [物体类型] standing side by side in a straight-on front view on a
clean white surface, evenly spaced at the same distance, creating a clear
size comparison: [参照物 A], [参照物 B], and [主产品] which is visibly
much larger than both. Floor-level camera angle with a hint of upward
tilt to exaggerate the height of the main product.
Soft even studio lighting, gentle contact shadows, plain light-grey
backdrop, generous empty space above for text.
No text, no letters, no labels, no logo, no people.
```

### 4. 结构剖面

```
Technical cutaway render of [产品], sliced vertically down the middle to
reveal its layered construction in cross-section: [外层], then [中间层],
then [内层]. The cut plane is crisp and clean, each layer distinctly
readable. Frontal straight-on view, studio lighting with soft reflections,
pale grey seamless background, industrial design render aesthetic.
No text, no letters, no labels, no arrows, no logo, no people.
```

### 5. 材质/内壁俯拍

```
Top-down photograph looking straight into [产品], showing [内壁材质描述]
with no contents: brushed metal / matte surface catching soft light,
[其他特征]. Clean pale-grey surface around the product, minimal and bright.
Extremely sharp focus on the surface texture, photorealistic macro.
No text, no letters, no logo, no watermark, no hands, no people.
```

### 6. 工艺细节微距

```
Extreme macro product photograph of [具体部位], shot from [角度]:
[要展示的关键特征，例如 the seamless junction where the handle meets the
body, smooth continuous moulding with no visible seam or gap],
fine surface texture, a soft highlight running along the edge.
Very shallow depth of field with [关键部位] tack sharp, blurred background.
Soft studio light from the upper left.
Photorealistic, extremely detailed surface texture, premium craftsmanship.
No text, no letters, no logo, no watermark, no hands, no people.
```

### 7. 场景图

```
Vertical lifestyle photograph of [场景描述] in [光线时段]:
[产品] stands prominently in the [位置], next to [场景道具].
[光源描述] diffuses warm daylight across the scene, gentle shadows on
[台面材质], shallow depth of field with the product tack sharp.
[风格定位], warm neutral colour grading.
Generous empty space in the [方位] for text overlay.
No text, no letters, no logo, no people, no hands.
```

### 8. 内部状态实证（冰块/内容物）

```
Vertical e-commerce detail page image, [视角] looking into an open [产品]:
inside [内容物描述，例如 several large clear ice cubes, two lemon slices,
condensation droplets on the inner wall]. Cool daylight, extremely high
clarity, the framing emphasises [要传达的特征].
Clean pale surface, a few scattered [点缀物] at the frame edges.
Generous empty space at the top for text overlay.
No text, no letters, no logo, no watermark, no people, no hands.
Macro product photography, razor-sharp detail, premium commercial quality.
```

## 一致性控制

同一套素材里，产品必须看起来是同一个。做法：

1. **固定一段产品描述**（材质、颜色、关键配件），复制到每条 prompt
2. **固定光位**（例如统一「soft studio light from the upper left」）
3. **固定背景色系**
4. 每批生成后立刻拼图对比，形态不一致的单独重生成

即使这样，跨图仍可能有细微差异（高度、把手曲率、配色深浅）。**这是当前生成模型的固有限制**，交付时必须主动说明，并建议实拍统一。

## 出图后必须做的两步

**第一步：裁掉水印**
模型输出右下角通常带生成水印。用 PIL 裁掉底部约 8.5% 的高度最干净：

```python
from PIL import Image
im = Image.open(path)
w, h = im.size
im.crop((0, 0, w, int(h * 0.915))).save(path)
```

不要用 CSS `scale` 去推走水印——会残留半个字。

**第二步：拼图自检**
把同批出图拼成一张网图，逐张看：结构对不对、有没有畸形、关键部件在不在。不合格的立刻重生成，不要带进版式。
