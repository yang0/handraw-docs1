"""批量渲染 HTML 版式为 PNG，并可选裁掉底部多余留白。

用法：
    1. 在本目录放 jobs.json：
       [
         {"html": "w02.html", "out": "02-全景.png", "height": 980},
         {"html": "w03.html", "out": "03-多色.png", "height": 640},
         {"html": "w01.html", "out": "01-首屏.png", "height": 1100,
          "bg": [16, 40, 28]}
       ]
    2. python render.py

规则：
    height 必须等于该页 .stage 的 CSS 高度，成图高度 = height × 2。
    bg 是该页的底色 RGB，用于自动裁掉底部空白。
      浅色页不用写（默认白）；深色页必须写，否则整页会被判成有内容，输出超高图。
    bg 同时可以写 "none" 关闭该页的裁剪。
输出目录：同级 ../成品/
"""

import json
import os
import subprocess
import sys
import urllib.parse

from PIL import Image

CHROME_CANDIDATES = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/usr/bin/google-chrome",
    "/usr/bin/chromium",
    "/usr/bin/chromium-browser",
]

SCALE = 2
WIDTH = 750


def find_chrome():
    for p in CHROME_CANDIDATES:
        if os.path.exists(p):
            return p
    return None


def trim_bottom(path, bg, keep=80, tol=12):
    """裁掉底部连续空白，保留 keep 像素缓冲。bg 必须是该页实际底色。"""
    img = Image.open(path).convert("RGB")
    w, h = img.size
    px = img.load()
    bgc = tuple(bg)
    # 从底部往上找第一行有内容的像素行
    last = -1
    for y in range(h - 1, -1, -1):
        row_has = False
        for x in range(0, w, 3):          # 隔点采样，够用且快
            r, g, b = px[x, y]
            if max(abs(r - bgc[0]), abs(g - bgc[1]), abs(b - bgc[2])) > tol:
                row_has = True
                break
        if row_has:
            last = y
            break
    if last < 0:
        return w, h                        # 整页空白，不动
    new_h = min(h, last + 1 + keep)
    if new_h >= h:
        return w, h
    img.crop((0, 0, w, new_h)).save(path, optimize=True)
    return w, new_h



def main():
    here = os.path.dirname(os.path.abspath(__file__))
    chrome = find_chrome()
    if not chrome:
        print("找不到 Chrome，请手动修改 CHROME_CANDIDATES")
        sys.exit(1)

    cfg = os.path.join(here, "jobs.json")
    if not os.path.exists(cfg):
        print("缺少 jobs.json")
        sys.exit(1)

    jobs = json.load(open(cfg, encoding="utf-8"))
    out_dir = os.path.join(os.path.dirname(here), "成品")
    os.makedirs(out_dir, exist_ok=True)

    ok, fail = 0, 0
    for job in jobs:
        src = os.path.join(here, job["html"])
        if not os.path.exists(src):
            print("  跳过（文件不存在）:", job["html"])
            fail += 1
            continue

        url = "file:///" + urllib.parse.quote(src.replace("\\", "/"))
        dst = os.path.join(out_dir, job["out"])
        h = int(job["height"])

        cmd = [
            chrome, "--headless=new", "--disable-gpu", "--no-sandbox",
            "--hide-scrollbars",
            "--force-device-scale-factor=%d" % SCALE,
            "--virtual-time-budget=6000",
            "--window-size=%d,%d" % (WIDTH, h),
            "--screenshot=" + dst,
            url,
        ]
        subprocess.run(cmd, capture_output=True, text=True, timeout=180)

        if os.path.exists(dst):
            size_kb = os.path.getsize(dst) / 1024
            note = ""
            bg = job.get("bg", [255, 255, 255])
            if bg != "none":
                w0, h0 = Image.open(dst).size
                w1, h1 = trim_bottom(dst, bg)
                if h1 < h0:
                    note = "  (裁掉底部 %dpx)" % (h0 - h1)
                    size_kb = os.path.getsize(dst) / 1024
            print("  OK  %-12s -> %-22s %dx%d  %.0fKB%s" % (
                job["html"], job["out"], WIDTH * SCALE, h * SCALE, size_kb, note))
            ok += 1
        else:
            print("  ERR %-12s 渲染失败" % job["html"])
            fail += 1

    print("\n完成：成功 %d，失败 %d\n输出目录：%s" % (ok, fail, out_dir))


if __name__ == "__main__":
    main()
