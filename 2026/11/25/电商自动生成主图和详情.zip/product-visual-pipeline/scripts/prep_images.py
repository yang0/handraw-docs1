"""素材预处理三件事：裁水印、拼总览、拼节奏条。

用法：
    python prep_images.py wm   <图片目录>            裁掉生成水印（底部 8.5%）
    python prep_images.py grid <图片目录> [列数]      拼网格总览 -> _overview.png
    python prep_images.py strip <图片目录> [缩略宽]   拼横向节奏条 -> _strip.png
"""

import os
import sys

from PIL import Image


def trim_watermark(folder, ratio=0.085):
    """裁掉图片底部含水印的条带。只处理该目录下的 png。"""
    for name in sorted(os.listdir(folder)):
        if not name.lower().endswith(".png") or name.startswith("_"):
            continue
        p = os.path.join(folder, name)
        im = Image.open(p)
        w, h = im.size
        im.crop((0, 0, w, h - int(h * ratio))).save(p, optimize=True)
        print("  %-40s %dx%d -> %dx%d" % (name, w, h, w, h - int(h * ratio)))


def build_grid(folder, cols=5, tw=300, gap=10):
    files = sorted(f for f in os.listdir(folder)
                   if f.lower().endswith(".png") and not f.startswith("_"))
    if not files:
        print("目录里没有 png")
        return
    ims = []
    for f in files:
        im = Image.open(os.path.join(folder, f)).convert("RGB")
        ims.append(im.resize((tw, int(im.height * tw / im.width)), Image.LANCZOS))

    rows = (len(ims) + cols - 1) // cols
    row_h = [max(ims[i * cols + j].height for j in range(cols)
                 if i * cols + j < len(ims)) for i in range(rows)]
    W = cols * tw + (cols + 1) * gap
    H = sum(row_h) + (rows + 1) * gap
    canvas = Image.new("RGB", (W, H), (238, 236, 232))

    y = gap
    for i in range(rows):
        x = gap
        for j in range(cols):
            k = i * cols + j
            if k >= len(ims):
                break
            canvas.paste(ims[k], (x, y))
            x += tw + gap
        y += row_h[i] + gap

    out = os.path.join(folder, "_overview.png")
    canvas.save(out, optimize=True)
    print("  _overview.png %dx%d（%d 张）" % (canvas.size[0], canvas.size[1], len(ims)))


def build_strip(folder, tw=92, gap=7):
    files = sorted(f for f in os.listdir(folder)
                   if f.lower().endswith(".png") and not f.startswith("_"))
    if not files:
        print("目录里没有 png")
        return
    ims = []
    for f in files:
        im = Image.open(os.path.join(folder, f)).convert("RGB")
        ims.append(im.resize((tw, int(im.height * tw / im.width)), Image.LANCZOS))

    H = max(i.height for i in ims) + gap * 2
    W = len(ims) * tw + (len(ims) + 1) * gap
    canvas = Image.new("RGB", (W, H), (238, 236, 232))
    x = gap
    for im in ims:
        canvas.paste(im, (x, gap))
        x += tw + gap

    out = os.path.join(folder, "_strip.png")
    canvas.save(out, optimize=True)
    print("  _strip.png %dx%d（%d 张）" % (canvas.size[0], canvas.size[1], len(ims)))


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(0)

    mode, folder = sys.argv[1], sys.argv[2]
    if mode == "wm":
        trim_watermark(folder)
    elif mode == "grid":
        cols = int(sys.argv[3]) if len(sys.argv) > 3 else 5
        build_grid(folder, cols=cols)
    elif mode == "strip":
        tw = int(sys.argv[3]) if len(sys.argv) > 3 else 92
        build_strip(folder, tw=tw)
    else:
        print(__doc__)
