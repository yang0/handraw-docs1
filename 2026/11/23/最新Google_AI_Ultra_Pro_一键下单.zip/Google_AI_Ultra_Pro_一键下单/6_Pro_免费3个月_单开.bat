@echo off
chcp 65001 >nul
title Pro 5TB - FREE 3 months
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8

echo ============================================================
echo   Google AI Pro (5 TB)  -  FREE 3 months
echo   SKU: g1.play.2tb.ai   offer: eft-3mo
echo   TOTAL COST: US$0.00   (standalone, no stacking)
echo ============================================================
echo.

python ultra0.py --account "current@device" --no-add --force --plan pro3

echo.
pause
