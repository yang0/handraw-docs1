@echo off
chcp 65001 >nul
title Pro 5TB - FREE +6 months (spare)
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8

echo ============================================================
echo   Google AI Pro (5 TB)  -  spare FREE 6 months pack
echo   offer: 6months-eft-ss-2026
echo   TOTAL COST: US$0.00
echo ============================================================
echo.

python ultra0.py --account "current@device" --no-add --force --stack --plan pro6c

echo.
pause
