@echo off
chcp 65001 >nul
title Pro 5TB - FREE +6 months (step 2)
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8

echo ============================================================
echo   Google AI Pro (5 TB)  -  FREE 6 months STACKED
echo   Uses subscription upgrade: old purchaseToken + replace mode
echo   TOTAL COST: US$0.00   (run ONLY after step 1 succeeded)
echo ============================================================
echo.

python ultra0.py --account "current@device" --no-add --force --stack --plan pro6

echo.
pause
