@echo off
chcp 65001 >nul
title Pro 5TB - FREE 12 months (step 1)
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8

echo ============================================================
echo   Google AI Pro (5 TB)  -  FREE 12 months
echo   SKU: g1.2tb.ai.subs_variant   offer: 12months-eft
echo   TOTAL COST: US$0.00
echo   This is a brand new subscription (no token read needed).
echo ============================================================
echo.

python ultra0.py --account "current@device" --no-add --force --plan pro12

echo.
pause
