@echo off
chcp 65001 >nul
title Ultra 20TB - 3 months 2 zhe (US$19.99)
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8

echo ============================================================
echo   Google AI Ultra (20 TB / 5x)
echo   SKU: g1.20tb.3months_ip_80p
echo   First 3 MONTHS: US$19.99/month  (2 zhe)
echo   From month 4:   US$99.99/month
echo   3-MONTH TOTAL:  US$59.97
echo ============================================================
echo.

python ultra0.py --account "current@device" --no-add --force --allow-paid --sku g1.20tb.3months_ip_80p

echo.
pause
