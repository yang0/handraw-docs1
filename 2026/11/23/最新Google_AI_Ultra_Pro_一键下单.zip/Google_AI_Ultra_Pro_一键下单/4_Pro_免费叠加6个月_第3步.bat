@echo off
chcp 65001 >nul
title Pro 5TB - FREE +6 months (step 3)
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8

echo ============================================================
echo   Google AI Pro (5 TB)  -  FREE 6 months STACKED (2nd)
echo   After this step total = 24 months
echo   TOTAL COST: US$0.00
echo ============================================================
echo.

python ultra0.py --account "current@device" --no-add --force --stack --plan pro6b

echo.
pause
