@echo off
chcp 65001 >nul
title Ultra 30TB - 3 months 2.5 zhe (US$49.99)
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8

echo ============================================================
echo   Google AI Ultra (30 TB / 20x)
echo   SKU: g1.ai.ultra.3months_ip_75p.acq
echo   First 3 MONTHS: US$49.99/month  (2.5 zhe)
echo   From month 4:   US$199.99/month
echo   3-MONTH TOTAL:  US$149.97
echo ============================================================
echo.

python ultra0.py --account "current@device" --no-add --force --allow-paid --sku g1.ai.ultra.3months_ip_75p.acq

echo.
pause
